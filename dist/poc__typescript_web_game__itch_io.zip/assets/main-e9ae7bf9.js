(function(){const o=document.createElement("link").relList;if(o&&o.supports&&o.supports("modulepreload"))return;for(const e of document.querySelectorAll('link[rel="modulepreload"]'))i(e);new MutationObserver(e=>{for(const t of e)if(t.type==="childList")for(const l of t.addedNodes)l.tagName==="LINK"&&l.rel==="modulepreload"&&i(l)}).observe(document,{childList:!0,subtree:!0});function n(e){const t={};return e.integrity&&(t.integrity=e.integrity),e.referrerPolicy&&(t.referrerPolicy=e.referrerPolicy),e.crossOrigin==="use-credentials"?t.credentials="include":e.crossOrigin==="anonymous"?t.credentials="omit":t.credentials="same-origin",t}function i(e){if(e.ep)return;e.ep=!0;const t=n(e);fetch(e.href,t)}})();const p=""+new URL("typescript-0686e01f.svg",import.meta.url).href,d=""+new URL("../vite.svg",import.meta.url).href;function f(r){let o=0;const n=i=>{o=i,r.innerHTML=`count is ${o}`};r.addEventListener("click",()=>n(o+1)),n(0)}document.querySelector("#app").innerHTML=`
  <div>
    <a href="https://vitejs.dev" target="_blank">
      <img src="${d}" class="logo" alt="Vite logo" />
    </a>
    <a href="https://www.typescriptlang.org/" target="_blank">
      <img src="${p}" class="logo vanilla" alt="TypeScript logo" />
    </a>
    <h1>Vite + TypeScript</h1>
    <div class="card">
      <button id="counter" type="button"></button>
    </div>
    <p class="read-the-docs">
      Click on the Vite and TypeScript logos to learn more
    </p>
  </div>
`;f(document.querySelector("#counter"));const s=1e3/60;let a=s,c=null;const m=s*5;function u(r){c==null&&(c=r),console.log("tick",r);let o=r-c;for(c=r,a+=Math.min(o,m);a>=s;)g(),a-=s;y(),requestAnimationFrame(u)}requestAnimationFrame(u);function g(){console.error("UPDATE",performance.now())}function y(){console.warn("RENDER",performance.now())}
